import { loadSettings } from './settings.js';

const BADGES = {
  working: { text: '…', color: '#5b6b58' },
  done: { text: '✓', color: '#2c7f12' },
  failed: { text: '✗', color: '#c62828' },
};

let busy = false;
let badgeTimer;

function showBadge({ text, color }) {
  clearTimeout(badgeTimer);
  chrome.action.setBadgeBackgroundColor({ color });
  chrome.action.setBadgeText({ text });
}

// Chrome keeps the service worker alive for 30 seconds after an event,
// so a two-second timer always gets to run.
function hideBadgeSoon() {
  badgeTimer = setTimeout(() => chrome.action.setBadgeText({ text: '' }), 2000);
}

// One click on the toolbar icon: clear what the settings say, then reload
// the tab the click came from.
chrome.action.onClicked.addListener(async (tab) => {
  if (busy) return; // a second click while clearing does nothing
  busy = true;

  try {
    const { timeRangeMs, dataTypes } = await loadSettings();

    if (!Object.values(dataTypes).some(Boolean)) {
      await chrome.runtime.openOptionsPage(); // nothing picked yet, so ask
      return;
    }

    showBadge(BADGES.working);
    const since = timeRangeMs === 0 ? 0 : Date.now() - timeRangeMs;
    await chrome.browsingData.remove({ since }, dataTypes);
    showBadge(BADGES.done);

    // Some tabs can't be reloaded (a browser settings page, say). The data
    // is already cleared by then, so that isn't a failure.
    await chrome.tabs.reload(tab.id).catch(() => {});
  } catch (error) {
    console.error('Fresh Pull could not clear:', error);
    showBadge(BADGES.failed);
  } finally {
    hideBadgeSoon();
    busy = false;
  }
});

// On first install, open the settings so the first click never clears
// more than the person chose.
chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === chrome.runtime.OnInstalledReason.INSTALL) {
    chrome.runtime.openOptionsPage();
  }
});
