// Fresh Pull's settings: what it can clear, how far back, and the defaults.
// Shared by background.js (the click) and options.js (the settings page).

export const DATA_TYPES = [
  'cache', 'history', 'cookies', 'downloads',
  'formData', 'passwords', 'localStorage', 'indexedDB',
];

// In milliseconds: 15 minutes, 1 hour, 24 hours, 7 days, 30 days, all time.
export const TIME_RANGES = [900_000, 3_600_000, 86_400_000, 604_800_000, 2_592_000_000, 0];

export const DEFAULTS = Object.freeze({
  timeRangeMs: 86_400_000,
  dataTypes: Object.freeze({
    cache: true, history: true, cookies: true, downloads: true,
    formData: false, passwords: false, localStorage: false, indexedDB: false,
  }),
});

// The name dates from version 1, when the extension was called ClearSweep.
// Keeping it means nobody loses their settings on update.
const STORAGE_KEY = 'clearsweepSettings';

// Storage can hold anything, so only known time ranges and data types get
// through. Anything missing or malformed falls back to its default.
export function clean(stored) {
  const timeRangeMs = TIME_RANGES.includes(stored?.timeRangeMs)
    ? stored.timeRangeMs
    : DEFAULTS.timeRangeMs;

  const dataTypes = {};
  for (const type of DATA_TYPES) {
    const value = stored?.dataTypes?.[type];
    dataTypes[type] = typeof value === 'boolean' ? value : DEFAULTS.dataTypes[type];
  }

  return { timeRangeMs, dataTypes };
}

export async function loadSettings() {
  const { [STORAGE_KEY]: stored } = await chrome.storage.sync.get(STORAGE_KEY);
  return clean(stored);
}

export function saveSettings(settings) {
  return chrome.storage.sync.set({ [STORAGE_KEY]: clean(settings) });
}
