import { DATA_TYPES, DEFAULTS, loadSettings, saveSettings } from './settings.js';

const form = document.getElementById('settings');
const status = document.getElementById('status');

function show(settings) {
  form.elements.timeRangeMs.value = String(settings.timeRangeMs);
  for (const type of DATA_TYPES) {
    form.elements[type].checked = settings.dataTypes[type];
  }
}

function read() {
  return {
    timeRangeMs: Number(form.elements.timeRangeMs.value),
    dataTypes: Object.fromEntries(DATA_TYPES.map((type) => [type, form.elements[type].checked])),
  };
}

async function save(settings, message) {
  try {
    await saveSettings(settings);
    status.textContent = message;
  } catch (error) {
    status.textContent = `Couldn't save: ${error.message}`;
  }
}

// Every change saves straight away, so there is no Save button to forget.
form.addEventListener('change', () => save(read(), 'Saved'));

document.getElementById('reset').addEventListener('click', () => {
  show(DEFAULTS);
  save(DEFAULTS, 'Back to the defaults');
});

show(await loadSettings());
