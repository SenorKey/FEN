# Fresh Pull

A Chrome extension that clears your browsing data in one click. Pick what to
clear once in Options, then click the toolbar icon whenever you want a fresh
start. It clears, shows a check mark, and reloads your tab.

Page: https://frontendneeded.com/fresh-pull/

## What it asks for

- `browsingData`, to clear what you picked
- `storage`, to remember what you picked (synced with your Chrome profile)

Nothing else. No access to the pages you visit, no servers, no tracking, and
nothing loaded from the web. The content security policy in `manifest.json`
only lets the extension run its own files.

## Files

| File            | What it does                                                 |
| --------------- | ------------------------------------------------------------ |
| `manifest.json` | Name, permissions, icons, security policy                    |
| `settings.js`   | The defaults, and the check every saved setting goes through |
| `background.js` | The click: clear, show the badge, reload the tab             |
| `options.html`  | The settings page (`options.css`, `options.js`)              |

## Install it yourself

1. Download and unzip it.
2. Open `chrome://extensions` and turn on **Developer mode**.
3. Click **Load unpacked** and pick the unzipped folder.
4. Pin Fresh Pull to the toolbar. The settings open the first time.

Needs Chrome 120 or newer. Tested in Chromium 153.

## Make the download

From this folder:

```bash
zip -X -r fresh-pull-2.1.0.zip manifest.json background.js settings.js options.html options.css options.js icons README.md
```
